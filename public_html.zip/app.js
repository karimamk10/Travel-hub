/**
 * TravelHub - Modern Travel Booking Platform Logic (Green Emerald Theme)
 * Senior Engineering Architecture - Modular Vanilla JS
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize lucide icons
  if (window.lucide) {
    lucide.createIcons();
  }

  // Application State
  const state = {
    wishlist: JSON.parse(localStorage.getItem('travelhub_wishlist')) || [],
    currency: 'USD',
    currencySymbols: { USD: '$', EUR: '€', GBP: '£', CAD: 'CA$', AUD: 'A$' },
    exchangeRates: { USD: 1, EUR: 0.92, GBP: 0.79, CAD: 1.35, AUD: 1.52 },
    activeSearchTab: 'flights',
    activeTourFilter: 'all',
    activeTourSort: 'recommended',
    map: null,
    mapMarkers: [],
    properties: [
      {
        id: 'prop-1',
        title: 'Grand Plaza Hotel & Spa',
        location: 'Paris, France',
        price: 180,
        rating: 4.9,
        reviews: 245,
        lat: 48.8566,
        lng: 2.3522,
        image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80',
        badge: '5 Star Luxury'
      },
      {
        id: 'prop-2',
        title: 'Seaside Sanctuary Resort',
        location: 'Bali, Indonesia',
        price: 110,
        rating: 4.8,
        reviews: 312,
        lat: -8.4095,
        lng: 115.1889,
        image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&q=80',
        badge: 'Oceanfront'
      },
      {
        id: 'prop-3',
        title: 'Alpine Horizon Lodge',
        location: 'Swiss Alps, Switzerland',
        price: 260,
        rating: 4.95,
        reviews: 188,
        lat: 46.5601,
        lng: 7.9126,
        image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=600&q=80',
        badge: 'Ski-in/Ski-out'
      },
      {
        id: 'prop-4',
        title: 'Kyoto Traditional Ryokan',
        location: 'Kyoto, Japan',
        price: 195,
        rating: 4.92,
        reviews: 420,
        lat: 35.0116,
        lng: 135.7681,
        image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=600&q=80',
        badge: 'Heritage'
      },
      {
        id: 'prop-5',
        title: 'Burj View Luxury Suite',
        location: 'Dubai, UAE',
        price: 320,
        rating: 4.87,
        reviews: 190,
        lat: 25.1972,
        lng: 55.2744,
        image: 'https://images.unsplash.com/photo-1512453979798-5ea904ac22ac?w=600&q=80',
        badge: 'Skyline View'
      }
    ],
    tours: [
      {
        id: 'tour-1',
        title: 'Santorini Sunset Luxury Catamaran Cruise',
        location: 'Santorini, Greece',
        category: 'water',
        price: 95,
        rating: 4.9,
        reviews: 328,
        duration: '5 hours',
        groupSize: 'Max 12',
        image: 'https://images.unsplash.com/photo-1506929562872-bb421503ef21?w=600&q=80',
        badge: 'Best Seller',
        description: 'Sail across the Aegean Sea on a luxury catamaran. Swim in hot springs, enjoy a BBQ dinner with wine, and watch world-famous Oia sunset.'
      },
      {
        id: 'tour-2',
        title: 'Authentic Tokyo Food & Izakaya Crawl',
        location: 'Tokyo, Japan',
        category: 'cultural',
        price: 75,
        rating: 4.85,
        reviews: 410,
        duration: '3.5 hours',
        groupSize: 'Max 8',
        image: 'https://images.unsplash.com/photo-1528164344705-47542687000d?w=600&q=80',
        badge: 'Top Rated',
        description: 'Discover hidden alleyways and taste authentic yakitori, ramen, and artisan sake alongside an expert local guide.'
      },
      {
        id: 'tour-4',
        title: 'Swiss Alps Panorama Train & Peak Hike',
        location: 'Interlaken, Switzerland',
        category: 'adventure',
        price: 135,
        rating: 4.78,
        reviews: 195,
        duration: '7 hours',
        groupSize: 'Group (15)',
        image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=80',
        badge: 'Scenic',
        description: 'Ride the historic cogwheel train to breathtaking alpine view spots followed by a guided nature walk with traditional fondue.'
      },
      {
        id: 'tour-5',
        title: 'Machu Picchu Sacred Valley Sunrise Tour',
        location: 'Cusco, Peru',
        category: 'cultural',
        price: 295,
        rating: 4.94,
        reviews: 380,
        duration: '2 days',
        groupSize: 'Small Group',
        image: 'https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=600&q=80',
        badge: 'UNESCO Heritage',
        description: 'Experience sunrise over the ancient Incan citadel with an archaeologist guide. Includes panoramic Vistadome train tickets.'
      },
      {
        id: 'tour-6',
        title: 'Dubai VIP Red Dunes Desert Safari & BBQ',
        location: 'Dubai, UAE',
        category: 'adventure',
        price: 85,
        rating: 4.75,
        reviews: 520,
        duration: '6 hours',
        groupSize: 'Shared 4x4',
        image: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600&q=80',
        badge: 'Popular',
        description: 'Thrilling dune bashing, sandboarding, camel rides, and a 5-star belly dancing gala dinner under desert stars.'
      }
    ]
  };

  // UI Component Selectors
  const header = document.getElementById('header');
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileNav = document.getElementById('mobileNav');
  const wishlistCountBadge = document.getElementById('wishlistCountBadge');
  const currencySelector = document.getElementById('currencySelector');

  // Search Tabs Elements
  const searchTabs = document.querySelectorAll('.search-tab');
  const searchForms = document.querySelectorAll('.search-form');

  // Tour Containers
  const toursGrid = document.getElementById('toursGrid');
  const tourFilterSelect = document.getElementById('tourFilter');
  const tourSortSelect = document.getElementById('tourSort');
  const tourCategoryPills = document.querySelectorAll('.category-pill');

  // Property Container
  const propertyListContainer = document.getElementById('propertyList');

  // Modals
  const tourModal = document.getElementById('tourModal');
  const modalOverlay = document.getElementById('modalOverlay');

  // Transfer Form Calculator
  const transferForm = document.getElementById('transferForm');
  const transferVehicleSelect = document.getElementById('transferVehicle');
  const transferPassengersSelect = document.getElementById('passengers');
  const transferEstimatedPrice = document.getElementById('transferEstimatedPrice');

  /* ==========================================================================
     1. Navigation & Header Effects
     ========================================================================== */
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.classList.add('shadow-lg', 'bg-white/95', 'backdrop-blur-md');
      header.classList.remove('bg-white/80');
    } else {
      header.classList.remove('shadow-lg', 'bg-white/95');
      header.classList.add('bg-white/80');
    }
  });

  if (mobileMenuBtn && mobileNav) {
    mobileMenuBtn.addEventListener('click', () => {
      const isOpen = mobileNav.classList.contains('active');
      if (isOpen) {
        mobileNav.classList.remove('active', 'opacity-100', 'pointer-events-auto');
        mobileNav.classList.add('opacity-0', 'pointer-events-none');
        document.body.classList.remove('overflow-hidden');
      } else {
        mobileNav.classList.add('active', 'opacity-100', 'pointer-events-auto');
        mobileNav.classList.remove('opacity-0', 'pointer-events-none');
        document.body.classList.add('overflow-hidden');
      }
    });

    mobileNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileNav.classList.remove('active', 'opacity-100', 'pointer-events-auto');
        mobileNav.classList.add('opacity-0', 'pointer-events-none');
        document.body.classList.remove('overflow-hidden');
      });
    });
  }

  /* ==========================================================================
     2. Currency & Wishlist Management
     ========================================================================== */
  function updateWishlistBadge() {
    if (!wishlistCountBadge) return;
    const count = state.wishlist.length;
    wishlistCountBadge.textContent = count;
    if (count > 0) {
      wishlistCountBadge.classList.remove('hidden');
    } else {
      wishlistCountBadge.classList.add('hidden');
    }
  }

  function toggleWishlist(id) {
    const index = state.wishlist.indexOf(id);
    let added = false;
    if (index > -1) {
      state.wishlist.splice(index, 1);
      showToast('Item removed from your wishlist', 'info');
    } else {
      state.wishlist.push(id);
      showToast('Item saved to your wishlist!', 'success');
      added = true;
    }
    localStorage.setItem('travelhub_wishlist', JSON.stringify(state.wishlist));
    updateWishlistBadge();
    renderTours();
    return added;
  }

  function updateWidgetCurrencies(newCurrency) {
    const containers = document.querySelectorAll(
      '.flight-widget-wrapper, .car-widget-wrapper, .transfer-widget-wrapper, .kiwitaxi-widget-wrapper, .bike-widget-wrapper, .citytours-widget-wrapper, .map-widget-wrapper, #cityToursWidgetContainer, #popularToursWidgetContainer, #popularRoutesWidgetContainer, #esimPopularWidgetContainer, .widget-script-holder'
    );
    containers.forEach(container => {
      const scripts = container.querySelectorAll('script');
      scripts.forEach(script => {
        if (script.src) {
          let newSrc = script.src;
          if (newSrc.includes('currency=')) {
            newSrc = newSrc.replace(/currency=[^&]+/gi, `currency=${newCurrency.toLowerCase()}`);
          } else if (newSrc.includes('curr=')) {
            newSrc = newSrc.replace(/curr=[^&]+/gi, `curr=${newCurrency.toUpperCase()}`);
          } else {
            newSrc += `&currency=${newCurrency.toLowerCase()}`;
          }

          if (newSrc !== script.src) {
            const newScript = document.createElement('script');
            newScript.async = true;
            newScript.charset = 'utf-8';
            newScript.src = newSrc;
            const parent = script.parentNode;
            script.remove();
            parent.appendChild(newScript);
          }
        }
      });

      const iframe = container.querySelector('iframe');
      if (iframe && iframe.src) {
        let newIframeSrc = iframe.src;
        if (newIframeSrc.includes('currency=')) {
          newIframeSrc = newIframeSrc.replace(/currency=[^&]+/gi, `currency=${newCurrency.toLowerCase()}`);
          iframe.src = newIframeSrc;
        } else if (newIframeSrc.includes('curr=')) {
          newIframeSrc = newIframeSrc.replace(/curr=[^&]+/gi, `curr=${newCurrency.toUpperCase()}`);
          iframe.src = newIframeSrc;
        }
      }
    });
  }

  if (currencySelector) {
    currencySelector.addEventListener('change', (e) => {
      state.currency = e.target.value;
      renderTours();
      renderProperties();
      renderMapMarkers();
      updateTransferPrice();
      updateWidgetCurrencies(state.currency);
      showToast(`Currency updated to ${state.currency} (${state.currencySymbols[state.currency]})`, 'info');
    });
  }

  function formatPrice(amountUSD) {
    const rate = state.exchangeRates[state.currency] || 1;
    const symbol = state.currencySymbols[state.currency] || '$';
    const converted = Math.round(amountUSD * rate);
    return `${symbol}${converted}`;
  }

  /* ==========================================================================
     3. Hero Search Tabs & Forms
     ========================================================================== */
  searchTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      searchTabs.forEach(t => {
        t.classList.remove('bg-primary', 'text-white', 'shadow-md');
        t.classList.add('bg-slate-100', 'text-slate-600', 'hover:bg-slate-200');
      });
      tab.classList.remove('bg-slate-100', 'text-slate-600', 'hover:bg-slate-200');
      tab.classList.add('bg-primary', 'text-white', 'shadow-md');

      searchForms.forEach(form => {
        if (form.id === `${target}Form`) {
          form.classList.remove('hidden');
          if (form.id === 'hotelsForm' || form.id === 'flightsForm' || form.id === 'carsForm' || form.id === 'transfersForm' || form.id === 'kiwitaxiForm') {
            form.classList.add('block');
          } else {
            form.classList.add('grid');
          }
        } else {
          form.classList.add('hidden');
          form.classList.remove('grid', 'block');
        }
      });
      state.activeSearchTab = target;
    });
  });

  // Handle Navbar triggers for search tabs
  document.querySelectorAll('.nav-tab-trigger').forEach(trigger => {
    trigger.addEventListener('click', (e) => {
      const tabTarget = trigger.dataset.tab;
      if (tabTarget) {
        const correspondingTab = document.querySelector(`.search-tab[data-tab="${tabTarget}"]`);
        if (correspondingTab) {
          correspondingTab.click();
        }
      }
    });
  });

  // Handle Search Submissions
  searchForms.forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="inline-block animate-spin mr-2">⏳</span> Searching Best Deals...`;

      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        
        const targetSection = document.getElementById('tours');
        if (targetSection) {
          targetSection.scrollIntoView({ behavior: 'smooth' });
        }
        showToast('Found 42+ amazing matching offers!', 'success');
      }, 1200);
    });
  });

  // Set min dates for check-in / check-out
  const todayStr = new Date().toISOString().split('T')[0];
  document.querySelectorAll('input[type="date"]').forEach(input => {
    input.min = todayStr;
  });

  /* ==========================================================================
     4. Map & Property Preview Integration (Leaflet.js)
     ========================================================================== */
  function initMap() {
    const mapContainer = document.getElementById('map');
    if (!mapContainer || !window.L) return;

    state.map = L.map('map', {
      zoomControl: false,
      scrollWheelZoom: false
    }).setView([40.0, 15.0], 3);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
      maxZoom: 19
    }).addTo(state.map);

    L.control.zoom({ position: 'topright' }).addTo(state.map);

    renderMapMarkers();
  }

  function renderMapMarkers() {
    if (!state.map || !window.L) return;

    state.mapMarkers.forEach(m => state.map.removeLayer(m));
    state.mapMarkers = [];

    state.properties.forEach(prop => {
      const priceText = formatPrice(prop.price);
      const customIcon = L.divIcon({
        className: 'custom-map-pin-container',
        html: `<div class="custom-map-pin" data-id="${prop.id}">${priceText}</div>`,
        iconSize: [60, 30],
        iconAnchor: [30, 15]
      });

      const marker = L.marker([prop.lat, prop.lng], { icon: customIcon }).addTo(state.map);
      marker.bindPopup(`
        <div class="p-1 max-w-[200px]">
          <img src="${prop.image}" alt="${prop.title}" class="w-full h-24 object-cover rounded-lg mb-2" />
          <h4 class="font-bold text-sm text-slate-900 leading-tight mb-1">${prop.title}</h4>
          <p class="text-xs text-slate-500 mb-1">📍 ${prop.location}</p>
          <div class="flex items-center justify-between mt-2">
            <span class="font-extrabold text-primary text-sm">${formatPrice(prop.price)}<span class="text-xs text-slate-400 font-normal">/night</span></span>
            <span class="text-xs text-amber-500 font-bold">★ ${prop.rating}</span>
          </div>
        </div>
      `);

      marker.on('click', () => {
        highlightProperty(prop.id);
      });

      state.mapMarkers.push(marker);
    });
  }

  function highlightProperty(propId) {
    document.querySelectorAll('.property-item').forEach(el => {
      if (el.dataset.id === propId) {
        el.classList.add('ring-2', 'ring-primary', 'bg-emerald-50/50');
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        el.classList.remove('ring-2', 'ring-primary', 'bg-emerald-50/50');
      }
    });

    document.querySelectorAll('.custom-map-pin').forEach(pin => {
      if (pin.dataset.id === propId) {
        pin.classList.add('active-pin');
      } else {
        pin.classList.remove('active-pin');
      }
    });
  }

  function renderProperties() {
    if (!propertyListContainer) return;
    propertyListContainer.innerHTML = state.properties.map(prop => `
      <div class="property-item group p-3 rounded-2xl bg-white border border-slate-200/80 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer flex gap-4 items-center" data-id="${prop.id}">
        <img src="${prop.image}" alt="${prop.title}" class="w-24 h-24 rounded-xl object-cover group-hover:scale-105 transition-transform duration-300" />
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-[10px] font-bold tracking-wide uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-primary">${prop.badge}</span>
            <span class="text-xs text-amber-500 font-bold flex items-center gap-0.5"><i data-lucide="star" class="w-3 h-3 fill-amber-400 text-amber-400"></i> ${prop.rating} (${prop.reviews})</span>
          </div>
          <h4 class="font-bold text-slate-900 truncate group-hover:text-primary transition-colors">${prop.title}</h4>
          <p class="text-xs text-slate-500 mb-2 truncate">📍 ${prop.location}</p>
          <div class="flex items-center justify-between">
            <div class="text-primary font-extrabold text-lg">${formatPrice(prop.price)}<span class="text-xs font-normal text-slate-400">/night</span></div>
            <button class="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-primary hover:text-white text-slate-700 text-xs font-semibold transition-all flex items-center gap-1">
              View <i data-lucide="arrow-right" class="w-3 h-3"></i>
            </button>
          </div>
        </div>
      </div>
    `).join('');

    document.querySelectorAll('.property-item').forEach(item => {
      item.addEventListener('click', () => {
        const id = item.dataset.id;
        const prop = state.properties.find(p => p.id === id);
        if (prop && state.map) {
          state.map.flyTo([prop.lat, prop.lng], 13, { duration: 1.5 });
          highlightProperty(id);
        }
      });
    });

    if (window.lucide) lucide.createIcons();
  }

  /* ==========================================================================
     5. Tour Catalog Filtering & Rendering
     ========================================================================== */
  function renderTours() {
    if (!toursGrid) return;

    let filtered = [...state.tours];

    if (state.activeTourFilter !== 'all') {
      filtered = filtered.filter(t => t.category === state.activeTourFilter);
    }

    if (state.activeTourSort === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (state.activeTourSort === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (state.activeTourSort === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    }

    if (filtered.length === 0) {
      toursGrid.innerHTML = `
        <div class="col-span-full py-16 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200">
          <p class="text-slate-400 font-medium text-lg">No tours found matching this category.</p>
          <button class="mt-4 px-5 py-2.5 bg-primary text-white rounded-full text-sm font-semibold hover:bg-emerald-700 transition" onclick="resetTourFilters()">View All Tours</button>
        </div>
      `;
      return;
    }

    toursGrid.innerHTML = filtered.map((tour, idx) => {
      const isSaved = state.wishlist.includes(tour.id);
      return `
        <article class="tour-card group bg-white rounded-3xl overflow-hidden border border-slate-200/80 shadow-md hover:shadow-2xl transition-all duration-500 flex flex-col transform hover:-translate-y-2" style="animation-delay: ${idx * 80}ms">
          <div class="relative aspect-[16/10] overflow-hidden bg-slate-100">
            <img src="${tour.image}" alt="${tour.title}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out" />
            <button class="wishlist-btn absolute top-4 right-4 w-10 h-10 rounded-full glass-card flex items-center justify-center text-slate-700 hover:text-red-500 hover:scale-110 transition-all z-10" data-id="${tour.id}" aria-label="Add to Wishlist">
              <i data-lucide="heart" class="w-5 h-5 ${isSaved ? 'fill-red-500 text-red-500' : ''}"></i>
            </button>
            ${tour.badge ? `<span class="absolute top-4 left-4 px-3 py-1 rounded-full bg-secondary text-white text-xs font-bold uppercase tracking-wider shadow-md">${tour.badge}</span>` : ''}
          </div>

          <div class="p-6 flex-1 flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span class="flex items-center gap-1 text-slate-600 font-medium"><i data-lucide="map-pin" class="w-3.5 h-3.5 text-primary"></i> ${tour.location}</span>
                <span class="flex items-center gap-1 font-bold text-amber-500"><i data-lucide="star" class="w-3.5 h-3.5 fill-amber-400 text-amber-400"></i> ${tour.rating} (${tour.reviews})</span>
              </div>
              <h3 class="font-bold text-slate-900 text-lg group-hover:text-primary transition-colors line-clamp-2 mb-3 leading-snug">${tour.title}</h3>
              <p class="text-slate-500 text-sm line-clamp-2 mb-4 leading-relaxed">${tour.description}</p>
            </div>

            <div>
              <div class="flex items-center gap-4 py-3 border-y border-slate-100 text-xs text-slate-500 font-medium mb-4">
                <span class="flex items-center gap-1"><i data-lucide="clock" class="w-3.5 h-3.5 text-slate-400"></i> ${tour.duration}</span>
                <span class="flex items-center gap-1"><i data-lucide="users" class="w-3.5 h-3.5 text-slate-400"></i> ${tour.groupSize}</span>
                <span class="flex items-center gap-1 text-emerald-600 font-semibold"><i data-lucide="shield-check" class="w-3.5 h-3.5"></i> Free Cancel</span>
              </div>

              <div class="flex items-center justify-between">
                <div>
                  <span class="text-xs text-slate-400 font-normal">From</span>
                  <div class="text-2xl font-extrabold text-slate-900 leading-none">${formatPrice(tour.price)}<span class="text-xs text-slate-400 font-normal">/person</span></div>
                </div>
                <button class="book-tour-btn px-5 py-2.5 rounded-2xl bg-primary text-white font-semibold text-sm hover:bg-emerald-700 hover:shadow-lg hover:shadow-emerald-500/25 transition-all" data-id="${tour.id}">
                  Book Now
                </button>
              </div>
            </div>
          </div>
        </article>
      `;
    }).join('');

    document.querySelectorAll('.wishlist-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        toggleWishlist(id);
      });
    });

    document.querySelectorAll('.book-tour-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        openTourModal(id);
      });
    });

    if (window.lucide) lucide.createIcons();
  }

  window.resetTourFilters = function() {
    state.activeTourFilter = 'all';
    if (tourFilterSelect) tourFilterSelect.value = 'all';
    tourCategoryPills.forEach(p => p.classList.remove('ring-2', 'ring-primary', 'bg-emerald-50'));
    renderTours();
  };

  if (tourFilterSelect) {
    tourFilterSelect.addEventListener('change', (e) => {
      state.activeTourFilter = e.target.value;
      renderTours();
    });
  }

  if (tourSortSelect) {
    tourSortSelect.addEventListener('change', (e) => {
      state.activeTourSort = e.target.value;
      renderTours();
    });
  }

  tourCategoryPills.forEach(pill => {
    pill.addEventListener('click', () => {
      const cat = pill.dataset.category;
      state.activeTourFilter = cat;
      if (tourFilterSelect) tourFilterSelect.value = cat;

      tourCategoryPills.forEach(p => p.classList.remove('ring-2', 'ring-primary', 'bg-emerald-50'));
      pill.classList.add('ring-2', 'ring-primary', 'bg-emerald-50');

      document.getElementById('tours').scrollIntoView({ behavior: 'smooth' });
      renderTours();
    });
  });

  /* ==========================================================================
     6. Airport Transfers Price Calculator
     ========================================================================== */
  function updateTransferPrice() {
    if (!transferEstimatedPrice) return;
    const baseRates = { sedan: 45, business: 85, suv: 110, van: 135 };
    const vehicle = transferVehicleSelect ? transferVehicleSelect.value : 'sedan';
    const baseUSD = baseRates[vehicle] || 45;
    
    transferEstimatedPrice.textContent = formatPrice(baseUSD);
  }

  if (transferVehicleSelect) transferVehicleSelect.addEventListener('change', updateTransferPrice);
  if (transferPassengersSelect) transferPassengersSelect.addEventListener('change', updateTransferPrice);

  if (transferForm) {
    transferForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const pickup = document.getElementById('pickupLocation').value;
      const dropoff = document.getElementById('dropoffLocation').value;
      const vehicle = transferVehicleSelect.value;
      const price = transferEstimatedPrice.textContent;

      showToast(`Transfer booked! ${vehicle.toUpperCase()} from ${pickup} to ${dropoff} for ${price}`, 'success');
      transferForm.reset();
      updateTransferPrice();
    });
  }

  /* ==========================================================================
     7. Tour Booking Quick View Modal
     ========================================================================== */
  function openTourModal(tourId) {
    const tour = state.tours.find(t => t.id === tourId);
    if (!tour || !tourModal) return;

    document.getElementById('modalTourTitle').textContent = tour.title;
    document.getElementById('modalTourImage').src = tour.image;
    document.getElementById('modalTourLocation').textContent = `📍 ${tour.location}`;
    document.getElementById('modalTourPrice').textContent = formatPrice(tour.price);
    document.getElementById('modalTourDescription').textContent = tour.description;

    tourModal.classList.remove('hidden');
    tourModal.classList.add('flex');
    modalOverlay.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
  }

  function closeModal() {
    if (tourModal) {
      tourModal.classList.add('hidden');
      tourModal.classList.remove('flex');
    }
    if (modalOverlay) {
      modalOverlay.classList.add('hidden');
    }
    document.body.classList.remove('overflow-hidden');
  }

  if (modalOverlay) modalOverlay.addEventListener('click', closeModal);
  document.querySelectorAll('.close-modal-btn').forEach(b => b.addEventListener('click', closeModal));

  const confirmBookingBtn = document.getElementById('confirmBookingBtn');
  if (confirmBookingBtn) {
    confirmBookingBtn.addEventListener('click', () => {
      closeModal();
      showToast('🎉 Booking Confirmed! We sent details to your email.', 'success');
    });
  }

  /* ==========================================================================
     8. Toast Notification System
     ========================================================================== */
  function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-slate-900 text-white border-l-4 border-emerald-500' : 'bg-slate-900 text-white border-l-4 border-teal-500';
    
    toast.className = `flex items-center gap-3 px-5 py-4 rounded-2xl shadow-2xl ${bgClass} transition-all duration-300 transform translate-y-8 opacity-0 max-w-md`;
    toast.innerHTML = `
      <span class="text-lg">${type === 'success' ? '✅' : '🌿'}</span>
      <p class="text-sm font-medium leading-snug">${message}</p>
    `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('translate-y-8', 'opacity-0');
    }, 10);

    setTimeout(() => {
      toast.classList.add('translate-y-8', 'opacity-0');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  /* ==========================================================================
     9. Countdown Timer for Deals Banner
     ========================================================================== */
  function startDealCountdown() {
    const hoursEl = document.getElementById('dealHours');
    const minsEl = document.getElementById('dealMins');
    const secsEl = document.getElementById('dealSecs');
    if (!hoursEl || !minsEl || !secsEl) return;

    let totalSeconds = 14 * 3600 + 42 * 60 + 15;

    setInterval(() => {
      if (totalSeconds <= 0) return;
      totalSeconds--;

      const h = Math.floor(totalSeconds / 3600);
      const m = Math.floor((totalSeconds % 3600) / 60);
      const s = totalSeconds % 60;

      hoursEl.textContent = String(h).padStart(2, '0');
      minsEl.textContent = String(m).padStart(2, '0');
      secsEl.textContent = String(s).padStart(2, '0');
    }, 1000);
  }

  const copyPromoBtn = document.getElementById('copyPromoBtn');
  if (copyPromoBtn) {
    copyPromoBtn.addEventListener('click', () => {
      navigator.clipboard.writeText('TRAVEL2026');
      showToast('Promo code "TRAVEL2026" copied to clipboard!', 'success');
    });
  }

  /* ==========================================================================
     10. Intersection Observer (Scroll Animations)
     ========================================================================== */
  const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -40px 0px' };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('opacity-100', 'translate-y-0');
        entry.target.classList.remove('opacity-0', 'translate-y-8');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.reveal-on-scroll').forEach(el => {
    el.classList.add('transition-all', 'duration-700', 'opacity-0', 'translate-y-8');
    observer.observe(el);
  });

  // Initial Boot Execution
  updateWishlistBadge();
  renderProperties();
  renderTours();
  initMap();
  updateTransferPrice();
  startDealCountdown();

  // Setup Native Hotel Search Form
  function setupNativeHotelForm() {
    const form = document.getElementById('nativeHotelSearchForm');
    if (!form) return;

    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const next2Days = new Date(today);
    next2Days.setDate(today.getDate() + 2);
    const next2DaysStr = next2Days.toISOString().split('T')[0];

    const checkinInp = document.getElementById('hotelCheckIn');
    const checkoutInp = document.getElementById('hotelCheckOut');

    if (checkinInp && checkoutInp) {
      checkinInp.min = todayStr;
      if (!checkinInp.value) checkinInp.value = todayStr;
      checkoutInp.min = todayStr;
      if (!checkoutInp.value) checkoutInp.value = next2DaysStr;

      checkinInp.addEventListener('change', () => {
        if (checkinInp.value > checkoutInp.value) {
          checkoutInp.value = checkinInp.value;
        }
        checkoutInp.min = checkinInp.value;
      });
    }

    if (!form.dataset.bound) {
      form.dataset.bound = 'true';
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const dest = document.getElementById('hotelDestination')?.value || 'Hotels';
        const submitBtn = form.querySelector('button[type="submit"]');
        const orig = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="inline-block animate-spin mr-2">⏳</span> Searching ${dest}...`;
        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = orig;
          showToast(`Found 150+ luxury hotel deals for ${dest}!`, 'success');
          const targetSection = document.getElementById('destinations');
          if (targetSection) targetSection.scrollIntoView({ behavior: 'smooth' });
        }, 1000);
      });
    }
  }

  setupNativeHotelForm();

  // Check if third-party tour widget iframe fails to load, crashes or returns WAF 403
  setTimeout(() => {
    ['cityToursWidgetContainer', 'popularToursWidgetContainer', 'specificTourWidgetContainer'].forEach(id => {
      const container = document.getElementById(id);
      if (!container) return;
      const iframe = container.querySelector('iframe');
      
      let isErrorState = !iframe || iframe.offsetHeight <= 80 || (iframe.src && (iframe.src.includes('campaign_id=89') || iframe.src.includes('product=')));
      
      try {
        if (iframe && iframe.contentWindow) {
          const bodyText = iframe.contentWindow.document.body ? iframe.contentWindow.document.body.innerText : '';
          if (bodyText.includes("couldn't find") || bodyText.includes("Request filtered") || bodyText.includes("WAF")) {
            isErrorState = true;
          }
        }
      } catch (e) {
        // Cross-origin restricted iframe that failed to expand
        if (iframe && iframe.offsetHeight < 120) {
          isErrorState = true;
        }
      }

      if (isErrorState) {
        container.innerHTML = `
          <div class="flex flex-col md:flex-row items-center justify-between mb-6 gap-4">
            <div>
              <span class="text-primary text-xs font-extrabold uppercase tracking-widest block mb-1">Handpicked Verified Experiences</span>
              <h3 class="font-extrabold text-slate-900 text-xl sm:text-2xl">Trending World Tours & Activities</h3>
            </div>
            <span class="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">3 Top Rated Deals</span>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 flex items-center gap-4 hover:shadow-lg hover:border-primary transition-all group cursor-pointer">
              <img src="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=200&q=80" alt="Paris Seine Cruise" class="w-20 h-20 rounded-xl object-cover group-hover:scale-105 transition-transform" />
              <div>
                <span class="text-[10px] font-extrabold text-emerald-600 uppercase tracking-wider block mb-0.5">Paris, France</span>
                <h4 class="font-bold text-slate-900 text-sm group-hover:text-primary transition-colors">Paris Seine River Cruise</h4>
                <p class="text-xs text-slate-500 mb-2">Skip line + Audio Guide</p>
                <span class="text-sm font-extrabold text-slate-900">${formatPrice(49)} <span class="text-[10px] text-slate-400 font-normal">/person</span></span>
              </div>
            </div>
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 flex items-center gap-4 hover:shadow-lg hover:border-primary transition-all group cursor-pointer">
              <img src="https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=200&q=80" alt="Rome Colosseum VIP" class="w-20 h-20 rounded-xl object-cover group-hover:scale-105 transition-transform" />
              <div>
                <span class="text-[10px] font-extrabold text-emerald-600 uppercase tracking-wider block mb-0.5">Rome, Italy</span>
                <h4 class="font-bold text-slate-900 text-sm group-hover:text-primary transition-colors">Colosseum VIP Arena Access</h4>
                <p class="text-xs text-slate-500 mb-2">Priority Entrance & Guide</p>
                <span class="text-sm font-extrabold text-slate-900">${formatPrice(65)} <span class="text-[10px] text-slate-400 font-normal">/person</span></span>
              </div>
            </div>
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 flex items-center gap-4 hover:shadow-lg hover:border-primary transition-all group cursor-pointer">
              <img src="https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=200&q=80" alt="Kyoto Temple Walk" class="w-20 h-20 rounded-xl object-cover group-hover:scale-105 transition-transform" />
              <div>
                <span class="text-[10px] font-extrabold text-emerald-600 uppercase tracking-wider block mb-0.5">Kyoto, Japan</span>
                <h4 class="font-bold text-slate-900 text-sm group-hover:text-primary transition-colors">Kyoto Zen Temples & Bamboo</h4>
                <p class="text-xs text-slate-500 mb-2">Full Day Private Excursion</p>
                <span class="text-sm font-extrabold text-slate-900">${formatPrice(89)} <span class="text-[10px] text-slate-400 font-normal">/person</span></span>
              </div>
            </div>
          </div>
        `;
      }
    });
  }, 2500);

  console.log('TravelHub Emerald Green Theme Initialized 🌿');
});
